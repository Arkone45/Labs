#ifndef mod
#define mod

class Matrix
{
private:
    int rows, cols;
    int **matr;
public:
    Matrix () = delete;
    Matrix (int a = 0, int b = 0);
    ~Matrix ();
    Matrix (const Matrix &smpl, int incr = 0);
    void printer ();
};

#endif
