#include <windows.h>
#include <fstream>
#include <clocale>
#include "8.h"

using namespace std;

int main(int argc, char* argv[])
{
    Matrix x (3, 3);
    Matrix y (4, 4);
    setlocale(LC_ALL, "Russian");
    SetConsoleOutputCP(1251);
    SetConsoleCP(1251);
    y.printer ();
    //Matrix y (x, 2);
    y = Matrix (x, 1);
    y.printer ();
    x.printer ();
    return 0;
}
