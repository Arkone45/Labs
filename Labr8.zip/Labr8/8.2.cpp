#include <stdio.h>
#include <malloc.h>
#include "8.h"


Matrix::Matrix (int a, int b) : rows(a), cols(b)
{
    matr = nullptr;
    matr = new int* [rows];
    for (int i = 0; i < rows; i++)
        matr[i] = nullptr;
    for (int i = 0; i < rows; i++)
    {
        matr[i] = new int [cols];
        for (int j = 0; j < cols; j++)
        {
            matr[i][j] = 0;
        }
    }
}

Matrix::~Matrix ()
{
    printf ("������������ ������ ������:\n");
    printf ("%d %d\n", rows, cols);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
            printf ("%d ", matr[i][j]);
        printf ("\n");
    }
    for (int i = 0; i < rows; i++)
        delete[] matr[i];
    rows = cols = 0;
    delete[] matr;
    printf (".\n");
}

Matrix::Matrix (const Matrix &smpl, int incr) : Matrix (smpl.rows, smpl.cols)
{
    rows = smpl.rows;
    cols = smpl.cols;
    /*matr = new int* [rows];
    for (int i = 0; i < rows; i++)
        matr[i] = new int [cols];*/
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            matr[i][j] = smpl.matr[i][j] + incr;
    printf ("����������� ���������.\n");
}

void Matrix::printer ()
{
    if (rows & cols)
    {
        printf ("�����: %d ��������: %d\n", rows, cols);
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                printf ("%d ", matr[i][j]);
            }
            printf ("\n");
        }
    }
    else
        printf ("������� �����.\n");
}
